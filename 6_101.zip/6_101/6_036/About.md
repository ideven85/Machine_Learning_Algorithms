# ml_6036_2020_captions


6.036 Introduction to Machine Learning. 

Course playList: [Intro to Machine Learning 6.036](https://www.youtube.com/playlist?list=PLxC_ffO4q_rW0bqQB80_vcQB09HOA3ClV)


Thanks to Jeffrey Shen for providing the original caption text that appears here, and thanks to the MIT EECS Department for funding captioning of these videos.

