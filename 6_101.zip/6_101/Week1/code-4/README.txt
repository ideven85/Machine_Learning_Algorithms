Today we will be using some Python builtins to make our code more
concise and "pythonic". For each question, you will be provided
a snippet of code. Your goal is to refactor the code to produce
the same output but more cleanly, making use of some Python
builtin functions

(see https://docs.python.org/3/library/functions.html)
