import lab

print(lab.Add(lab.Mul(lab.Num(40), lab.Num(20)), lab.Mul(lab.Var("z"), lab.Num(0))))
