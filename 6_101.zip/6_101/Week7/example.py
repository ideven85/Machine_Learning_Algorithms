def new_greet(name):
    print("Hello, " + name + "!")
    print("Modified code")


# function to add two numbers
def add(a, b):
    return a + b


# function to test add
