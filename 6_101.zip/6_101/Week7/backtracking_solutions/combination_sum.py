def combination_sum(candidates, target):
    candidates.sort()
    out = []
