class Solution:

    def isInterleave(self, s1: str, s2: str, s3: str) -> bool:
        """
        >>>self.isInterleave(s1 = "aabcc", s2 = "dbbca", s3 = "aadbbcbcac")
        True
        """
