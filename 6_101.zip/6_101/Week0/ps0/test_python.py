print("Hello, Moon!")
x = input("What do you want for your birthday? ")
print(x)
