"""
6.101 Lab:
LISP Interpreter Part 1
"""

#!/usr/bin/env python3
import os
import lab
import sys
import json

from scheme_utils import SchemeError
import pytest

TEST_DIRECTORY = os.path.dirname(__file__)


class NotImplemented:
    def __eq__(self, other):
        return False


def make_tester(func):
    """
    Helper to wrap a function so that, when called, it produces a
    dictionary instead of its normal result.  If the function call works
    without raising an exception, then the results are included.
    Otherwise, the dictionary includes information about the exception that
    was raised.
    """

    def _tester(*args):
        try:
            return {"ok": True, "output": func(*args)}
        except SchemeError as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return {"ok": False, "type": exc_type.__name__, "msg": str(e)}

    return _tester


def load_test_values(n):
    """
    Helper function to load test inputs/outputs
    """
    with open(os.path.join(TEST_DIRECTORY, "test_inputs", f"{n:02d}.txt")) as f:
        inputs = eval(f.read())
    with open(os.path.join(TEST_DIRECTORY, "test_outputs", f"{n:02d}.txt")) as f:
        outputs = eval(f.read())
    return inputs, outputs


def run_continued_evaluations(ins):
    """
    Helper to evaluate a sequence of expressions in an environment.
    """
    lab.eval = None
    lab.exec = None
    frame = lab.make_initial_frame()
    outs = []
    t = make_tester(lab.evaluate)
    for i in ins:
        out = t(i, frame)
        if out["ok"]:
            try:
                typecheck = (int, float, lab.Pair)
                func = list_from_ll
            except:
                typecheck = (int, float)
                func = lambda x: x if isinstance(x, typecheck) else "SOMETHING"
            out["output"] = func(out["output"])
        outs.append(out)
    return outs


def compare_outputs(x, y, msg):
    # y is expected, x is your result
    if x["ok"]:
        assert y["ok"], (
            msg
            + f'\n\nExpected an exception ({y.get("type", None)}), but got {x.get("output", None)!r}'
        )
        if isinstance(x["output"], (int, float)):
            assert type(x["output"]) == type(y["output"]), (
                msg
                + f'\n\nOutput has incorrect type (expected {type(y.get("output", None))} but got {type(x.get("output", None))}'
            )
            assert abs(x["output"] - y["output"]) <= 1e-6, (
                msg
                + f'\n\nOutput has incorrect value (expected {y.get("output", None)!r} but got {x.get("output", None)!r})'
            )
        else:
            assert x["output"] == y["output"], (
                msg
                + f'\n\nOutput has incorrect value (expected {y.get("output", None)!r} but got {x.get("output", None)!r})'
            )
    else:
        after = '' if not x.get("msg") else f'("{x.get("msg")}")'
        assert not y["ok"], (
            msg
            + f'\n\nDid not expect an exception\nresult:   {x.get("type", None)}{after}\nexpected: {y.get("output", None)!r}'
        )
        assert x["type"] == y["type"], (
            msg
            + f'\n\nExpected {y.get("type", None)} to be raised, not {x.get("type", None)}{after}'
        )
        assert x.get("when", "eval") == y.get("when", "eval"), (
            msg
            + f'\n\nExpected error to be raised at {y.get("when", "eval")} time, not at {x.get("when", "eval")} time.'
        )


def do_continued_evaluations(n):
    """
    Test that the results from running continued evaluations in the same
    environment match the expected values.
    """
    inp, out = load_test_values(n)
    msg = message(n)
    results = run_continued_evaluations(inp)
    for x, (result, expected) in enumerate(zip(results, out)):
        m = f"\nevaluate input line {x+2}: \n\t{repr(inp[x])}"
        m += f'\nexpected:\n\t{expected["output"] if expected.get("output") is not None else expected.get("type")}'
        m += f'\nresult:\n\t{result["output"] if result.get("output") is not None else result.get("type")}'
        compare_outputs(result, expected, msg + m)


def do_raw_continued_evaluations(n):
    """
    Test that the results from running continued evaluations in the same
    environment match the expected values.
    """
    with open(os.path.join(TEST_DIRECTORY, "test_outputs", f"{n:02d}.txt")) as f:
        expected = eval(f.read())
    env = lab.make_initial_frame()
    results = []
    t = make_tester(lab.evaluate)
    with open(os.path.join(TEST_DIRECTORY, "test_inputs", f"{n:02d}.scm")) as f:
        for line in iter(f.readline, ""):
            parsed = lab.parse(lab.tokenize(line.strip()))
            out = t(parsed, env)
            if out["ok"]:
                typecheck = (int, float)
                func = lambda x: x if isinstance(x, typecheck) else "SOMETHING"
                out["output"] = func(out["output"])
            out["expression"] = line.strip()
            results.append(out)
    for ix, (result, exp) in enumerate(zip(results, expected)):
        msg = f"for line {ix+1} in test_inputs/{n:02d}.scm:\n    {result['expression']}"
        compare_outputs(result, exp, msg=msg)


def run_test_number(n, func, fname=""):
    tester = make_tester(func)
    inp, out = load_test_values(n)
    msg = message(n)
    for x, (i, o) in enumerate(zip(inp, out)):
        m = f"\n{func.__name__ if not fname else fname} input line {x+2}: \n\t{repr(i)}"
        m += f'\nexpected:\n\t{o["output"] if o.get("output") is not None else o["type"]}'
        res = tester(i)
        if o.get("output") == "SOMETHING" and res.get("output") is not None:
            res["output"] = "SOMETHING" if not isinstance(res["output"], (int, float)) else res["output"]
        m += f'\nresult:\n\t{res.get("output") if res.get("output") is not None else res.get("type")}'
        if res.get("output") is None and res.get("msg"):
            m += f'\n\tmsg: {res.get("msg")}'
        compare_outputs(res, o, msg + m)


def message(n, include_code=False):
    sn = n if n >= 10 else "0" + str(n)
    msg = f"\nfor test_inputs/{sn}.txt"
    try:
        with open(os.path.join(TEST_DIRECTORY, "scheme_code", f"{n:02d}.scm")) as f:
            code = f.read()
        msg += f" and scheme_code/{n}.scm"
    except Exception as e:
        with open(os.path.join(TEST_DIRECTORY, "test_inputs", f"{n:02d}.txt")) as f:
            code = f.read()
    if include_code:
        msg += " that begins with\n"
        msg += code if len(code) < 80 else code[:80] + "..."
    return msg

## TESTS FOR TOKENIZATION AND PARSING


def test_tokenize_small():
    run_test_number(0, lab.tokenize)


def test_tokenize_lines():
    run_test_number(31, lab.tokenize)


def test_tokenize_comments():
    run_test_number(32, lab.tokenize)


def test_parse_small():
    run_test_number(1, lab.parse)


def test_parse_valid():
    run_test_number(33, lab.parse)


## TESTS FOR CALCULATOR


def test_calc_add_mul():
    run_test_number(4, lab.evaluate)


def test_calc_sub_div():
    run_test_number(5, lab.evaluate)


def test_calc_pair():
    run_test_number(34, lab.evaluate)


def test_calc_nested():
    run_test_number(35, lab.evaluate)


def test_calc_errors():
    run_test_number(93, lab.evaluate)


## TESTS FOR VARIABLE ASSIGNMENT AND LOOKUP


def test_simple_assignment_1():
    do_continued_evaluations(6)


def test_simple_assignment_2():
    do_continued_evaluations(7)


def test_bad_lookups():
    do_continued_evaluations(8)


def test_rename_builtin():
    do_continued_evaluations(9)


## TESTS FOR FUNCTION DEFINITION/APPLICATIONi


def test_simple_function():
    do_continued_evaluations(10)


def test_inline_lambda():
    do_continued_evaluations(11)


def test_closures():
    do_continued_evaluations(12)


## INTEGRATION TESTS


def test_short_definition():
    do_raw_continued_evaluations(13)


def test_dependent_definition():
    do_raw_continued_evaluations(14)


def test_scoping_1():
    do_raw_continued_evaluations(15)


def test_scoping_2():
    do_raw_continued_evaluations(16)


def test_scoping_3():
    do_raw_continued_evaluations(17)


def test_scoping_4():
    do_raw_continued_evaluations(18)


def test_scoping_5():
    do_raw_continued_evaluations(19)


def test_calling_errors():
    do_raw_continued_evaluations(20)


def test_functionception():
    do_raw_continued_evaluations(21)


def test_alias():
    do_raw_continued_evaluations(22)


def test_big_scoping_1():
    do_raw_continued_evaluations(23)


def test_big_scoping_2():
    do_raw_continued_evaluations(24)


def test_big_scoping_3():
    do_raw_continued_evaluations(25)


def test_big_scoping_4():
    do_raw_continued_evaluations(26)


## ADDITIONAL TESTS FOR COMMON ERRORS


def test_more_syntax():
    do_raw_continued_evaluations(27)


def test_nested_defines():
    do_raw_continued_evaluations(28)
